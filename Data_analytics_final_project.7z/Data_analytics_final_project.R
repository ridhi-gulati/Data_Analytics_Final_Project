#############################
#set working directory and load the data
setwd("C:/Users/ridhi/Downloads/Data_Analytics/DataSets/EPI")
energy_data<-read.csv(file="energy-usage.csv", header=TRUE)
energy_data
head(energy_data)
str(energy_data)

# To Get the unique Community area names in the dataset
unique(energy_data$COMMUNITY.AREA.NAME)


#Get the total count of the unique community area name
aggregate(data.frame(count=energy_data$COMMUNITY.AREA.NAME),list(value=energy_data$COMMUNITY.AREA.NAME),length)


attach(energy_data)

# removing rows with na values
ed<-na.omit(energy_data)
ed

# total energy consumption by area
library(dplyr)
energy_data %>% 
  group_by(COMMUNITY.AREA.NAME,) %>% 
  summarise_all(sum)

# get the total energy consumption based on each community area.
aggregate(.~ COMMUNITY.AREA.NAME,energy_data,sum)
thermal_sum<-aggregate(TOTAL.THERMS~COMMUNITY.AREA.NAME,energy_data,sum)


thermal_sum

# get the area which consumes more Thermal energy(10)
largest_10_thermal<-thermal_sum[order(thermal_sum$TOTAL.THERMS,decreasing=T)[1:10],]
largest_10_thermal

#get the area which consumes more energy
aggregate(.~ COMMUNITY.AREA.NAME,energy_data,sum)
kwh_sum<-aggregate(TOTAL.KWH~COMMUNITY.AREA.NAME,energy_data,sum)
kwh_sum


# get the area which consumes more Thermal energy(10)
largest_10_kwh<-kwh_sum[order(kwh_sum$TOTAL.KWH,decreasing=T)[1:10],]
largest_10_kwh


#get 10 lowest thermal consumption area
lowest_10_thermal<-thermal_sum[order(thermal_sum$TOTAL.THERMS,decreasing=F)[1:10],]
lowest_10_thermal


# get the area which consumes lowest kwh energy(10)
lowest_10_kwh<-kwh_sum[order(kwh_sum$TOTAL.KWH,decreasing=F)[1:10],]
lowest_10_kwh




##############################
#initial hypothisis to see relation between building type and total kwh and total population
#############################
e1<-energy_data
head(e1)
str(e1)
summary(e1)
attach(e1)

e0 <- subset(e1, select = c(BUILDING.TYPE, TOTAL.KWH, TOTAL.POPULATION))

# removing NA variables
energy_data1 <- na.omit(e0)

#Display the "head" and "tail" of the dataset, "energy_data1"
head(energy_data1)
tail(energy_data1)

#Transform 'BUILDING_TYPE' into a categorical variable (where 0 represents residential buildings and 1 represents non-residential buildings, which corresponds to both commercial and industrial buildings)

energy_data1$BUILDING.TYPE = as.character(energy_data1$BUILDING.TYPE)
energy_data1$BUILDING.TYPE[energy_data1$BUILDING.TYPE != "Residential"] = 0
energy_data1$BUILDING.TYPE[energy_data1$BUILDING.TYPE == "Residential"] = 1
#Categorize 'BUILDING.TYPE' as a factor and display its resulting levels
energy_data1$BUILDING.TYPE = as.factor(energy_data1$BUILDING.TYPE)
levels(energy_data1$BUILDING.TYPE)

str(energy_data1)

energy_model <- glm(energy_data1$BUILDING.TYPE~energy_data1$TOTAL.KWH+energy_data1$TOTAL.POPULATION, family = "binomial")
energy_model
#Display summary of the initial Hierarchical Multiple Linear Logistic Regression Model
summary(energy_model)


# take a sample of observations from "energy_data1", creating "energy_final".
S <- 50000
set.seed(45)
energy.index <- sample(1:nrow(energy_data1),S,replace=FALSE)
energy_final <- energy_data1[energy.index,]
#Generate  Logistic Regression Model 
energy_model_final <- glm(energy_final$BUILDING.TYPE~energy_final$TOTAL.KWH+energy_final$TOTAL.POPULATION, family = "binomial")
summary(energy_model_final)



##########################################
#perform EDA
##########################################

#Generate histograms for all of the different independent variables being considered in our sampled data ('TOTAL_KWH' and 'TOTAL_POPULATION')
hist(energy_final$TOTAL.KWH, xlab = "Total Energy Consumption [in kilowatt-hours]", main = "Histogram of Total Energy Consumption")


hist(energy_final$TOTAL.POPULATION, xlab = "Total Building Population", main = "Histogram of Total Building Population")

#Generate a boxplot of the data (Independent Variable = Energy Consumption)
boxplot(x = energy_final$TOTAL.KWH, pch=21, bg="darkviolet", main="Total Energy Consumption", xlab = "Total Energy Consumption [in kilowatt-hours]")

#Generate a boxplot of the data (Independent Variable = Population)
boxplot(x = energy_final$TOTAL.POPULATION, pch=21, bg="darkviolet", main="Total Building Population", xlab = "Building Population")

#Generate a scatterplot of the data: "Building Type" vs. "Energy Consumption"
plot(y = energy_final$BUILDING_TYPE,x = energy_final$TOTAL.KWH, pch=21, bg="darkviolet", main="Total Energy Consumption vs. Building Type", ylab = "Building Type", xlab = "Energy Consumption (in kilowatt-hours)")


#Generate a scatterplot of the data: "Building Type" vs. "Building Population"
plot(y = energy_final$BUILDING.TYPE,x = energy_final$TOTAL.POPULATION, pch=21, bg="darkviolet", main="Total Building Population vs. Building Type", ylab = "Building Type", xlab = "Building Population")


par(mfrow=c(1,1))
plot(fitted(energy_model_final),residuals(energy_model_final), main = "Residuals of 'energy_model_final' Against Fitted", font.main = 4, cex.main = 1.2)
mtext("Model 'energy_model_final' [Not Standardized]", font = 4, cex = 1.2)
abline(0,0, col='darkviolet', lwd=2.5)

#Create a "Quality of Fit Model" that plots the standardized residuals of "energy_model_final" against its fitted model.
par(mfrow=c(1,1))
standardized_energy_model <- rstandard(energy_model_final)
plot(fitted(energy_model_final),standardized_energy_model, main = "Standardized Residuals of 'energy_model_final'", font.main = 4, cex.main = 1.2)
mtext("Against Fitted Model 'energy_model_final'", font = 4, cex = 1.2)
abline(0,0, col='darkviolet', lwd=2.5)

#Generate a residuals plot for "energy_model_final"
plot(energy_model_final$residuals, pch=21, bg="darkviolet", main = "Residuals Plot for 'energy_model_final'")

#Generate histograms for the residuals of our model
hist(residuals(energy_model_final), xlab = "Residuals", main = "Histogram of Residuals of 'energy_model_final'")

#Generate a boxplot for the residuals of our model
boxplot(x = residuals(energy_model_final), pch=21, bg="darkviolet", main="Boxplot of Residuals of 'energy_model_final'", xlab = "Residuals")


#Create a Normal Q-Q Plot for the data pertaining to Building Type.
qqnorm(residuals(energy_model_final), main = "Normal Q-Q Plot for Residuals of 'energy_model_final'")
qqline(residuals(energy_model_final))


#Generate a residuals plot for "energy_model_final"
plot(energy_model_final$residuals, pch=21, bg="darkviolet", main = "Residuals Plot for 'energy_model_final'")




#####################################################
#subsetting the datset to run models
####################################################

first_set<-energy_data
attach(first_set)
second <- subset(first_set, select = c(BUILDING.TYPE,TOTAL.KWH,AVERAGE.BUILDING.AGE,TOTAL.UNITS,OCCUPIED.UNITS, TOTAL.POPULATION,KWH.TOTAL.SQFT))
third <- na.omit(second)
dim(third)
str(third)
range(third$TOTAL.KWH)
summary(third$TOTAL.KWH)

third$BUILDING.TYPE = as.character(third$BUILDING.TYPE)
third$BUILDING.TYPE[third$BUILDING.TYPE != "Residential"] = 0
third$BUILDING.TYPE[third$BUILDING.TYPE == "Residential"] = 1
#Categorize 'BUILDING.TYPE' as a factor and display its resulting levels
third$BUILDING.TYPE = as.factor(third$BUILDING.TYPE)
levels(third$BUILDING.TYPE)
str(third)
install.packages("schoolmath")
is.negative(third$TOTAL.KWH)

#sampling
S <- 50000
set.seed(45)
fourth <- sample(1:nrow(third),S,replace=FALSE)
final <- third[fourth,]

# divide kwh in factors
TWH<-cut(final$TOTAL.KWH, breaks=c(102,62341,237535,583174733), labels=c("low","medium","high"))
TWH[1:10]
final<-cbind(final,TWH)
str(final)
summary(final)


final<-na.omit(final)

train<-sample(1:49999,35000,replace=FALSE)
trd<-final[train,]
tsd<-final[-train,]

tsd<-na.omit(tsd)


##############################################
#Random Forest Model
##############################################

fit3<-randomForest(trd$TWH~trd$BUILDING.TYPE+trd$TOTAL.POPULATION+trd$TOTAL.UNITS+trd$OCCUPIED.UNITS+trd$AVERAGE.BUILDING.AGE+trd$KWH.TOTAL.SQFT,data=trd,importance=TRUE)
plot(fit3)
prediction2<-predict(model,tsd,type="class")
prediction2

##############################
acc_tab<-table(prediction2,tsd$TWH)
accuracy<-function(x){sum(diag(x)/(sum(rowSums(x))))*100}
accuracy(acc_tab)



##################################################
# Linear Model
#################################################
lmm<-lm(trd$TWH~trd$BUILDING.TYPE+trd$TOTAL.POPULATION+trd$TOTAL.UNITS+trd$OCCUPIED.UNITS+trd$AVERAGE.BUILDING.AGE+trd$KWH.TOTAL.SQFT)
lmm
summary(lmm)

#################################################
#KNN Model
#################################################

trControl <- trainControl(method = 'repeatedcv',
                          number = 10,
                          classProbs = TRUE,
                          repeats = 3)
attach(tsd)
set.seed(333)
fit <- train(TWH~BUILDING.TYPE+TOTAL.POPULATION+TOTAL.UNITS+KWH.TOTAL.SQFT+AVERAGE.BUILDING.AGE+OCCUPIED.UNITS,
             data = trd,
             tuneGrid = expand.grid(k=1:70),
             method = 'knn',
             metric = 'ROC',
             trControl = trControl,
             preProc = c('center', 'scale'))


fit
summary(fit)
plot(fit)
varImp(fit)
pred <- predict(fit, newdata = tsd)
pred
# plot the confusion matrix
confusionMatrix(pred, tsd$TWH)

#############################################
#DECISION TREE
#############################################

dt_model = rpart(TWH ~ BUILDING.TYPE+TOTAL.POPULATION+TOTAL.UNITS+KWH.TOTAL.SQFT+AVERAGE.BUILDING.AGE+OCCUPIED.UNITS, data = trd, method = "anova")

#Plotting tree
rpart.plot(dt_model)
dt_predictions = predict(dt_model, tsd)
dt_predictions
summary(dt_predictions)
